# A Tribute Page - Mark Zuckerberg
This page is a tribute to Mark Zuckerberg whose journey motivated me to pursue a career in web development thanks to the movie "The Social Network" and his many interviews & blogs!
